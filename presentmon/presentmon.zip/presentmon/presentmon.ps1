# Check administrator privileges
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "This script requires administrator privileges to record traces." -ForegroundColor Red
    Write-Host "Please run the script as administrator." -ForegroundColor Yellow
    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "Script directory: $scriptPath"

# Check PresentMon dependencies
Write-Host "`nChecking PresentMon dependencies..." -ForegroundColor Cyan

$presentMonPath = "$scriptPath\PresentMon.exe"
$configPath = "$scriptPath\PresentMon_Config.json"

if (-not (Test-Path $presentMonPath)) {
    Write-Host "PresentMon.exe was not found in the script directory: $scriptPath" -ForegroundColor Red
    Write-Host "Download PresentMon from https://github.com/GameTechDev/PresentMon/releases, rename it to PresentMon.exe, then move it into the script folder" -ForegroundColor Yellow

    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

# ---------------------------------------------------------
# Default settings (used the very first time, before a config file exists)
# No process selection needed: PresentMon with --multi_csv just records
# whatever is actively rendering (game, benchmark, etc.) when you hit the hotkey.
# ---------------------------------------------------------
$defaultConfig = [PSCustomObject]@{
    Hotkey         = "F10"
    DurationSec    = 30
    SessionCounter = 0
}

function Show-Config($cfg) {
    Write-Host ""
    Write-Host "Current settings:" -ForegroundColor Cyan
    Write-Host "  Hotkey   : $($cfg.Hotkey)"
    Write-Host "  Duration : $($cfg.DurationSec) seconds"
}

function Select-Hotkey($currentDefault) {
    $input = Read-Host -Prompt "Hotkey to start/stop recording [$currentDefault]"
    if ([string]::IsNullOrWhiteSpace($input)) { return $currentDefault }
    return $input
}

function Select-Duration($currentDefault) {
    $input = Read-Host -Prompt "Recording duration in seconds [$currentDefault]"
    if ([string]::IsNullOrWhiteSpace($input)) { return $currentDefault }
    if ($input -match '^\d+$') { return [int]$input }
    Write-Host "Invalid number, keeping default ($currentDefault)." -ForegroundColor Yellow
    return $currentDefault
}

# ---------------------------------------------------------
# Load or create config
# ---------------------------------------------------------
$config = $null
if (Test-Path $configPath) {
    try {
        $config = Get-Content $configPath -Raw | ConvertFrom-Json
        Show-Config $config
        $useExisting = Read-Host -Prompt "`nPress Enter to use these settings, or type 'edit' to change them"
    } catch {
        Write-Host "Could not read existing config file, it may be corrupted. Reconfiguring..." -ForegroundColor Yellow
        $config = $null
        $useExisting = "edit"
    }
} else {
    Write-Host "No config file found. Let's set one up." -ForegroundColor Yellow
    $config = $defaultConfig
    $useExisting = "edit"
}

if ($useExisting -eq "edit") {
    $newHotkey   = Select-Hotkey $config.Hotkey
    $newDuration = Select-Duration $config.DurationSec

    $existingCounter = if ($config.PSObject.Properties.Name -contains 'SessionCounter') { [int]$config.SessionCounter } else { 0 }

    $config = [PSCustomObject]@{
        Hotkey         = $newHotkey
        DurationSec    = $newDuration
        SessionCounter = $existingCounter
    }

    $config | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8
    Write-Host "`nSettings saved to: $configPath" -ForegroundColor Green
    Write-Host "You can edit this file directly next time if you want to tweak values by hand." -ForegroundColor Gray
}

$hotkey            = $config.Hotkey
$recordingDuration = $config.DurationSec

# Persistent unique session id: increments every run, stored in the config file.
if ($config.PSObject.Properties.Name -contains 'SessionCounter') {
    $sessionCounter = [int]$config.SessionCounter + 1
} else {
    $sessionCounter = 1
    $config | Add-Member -NotePropertyName SessionCounter -NotePropertyValue 0 -Force
}
$config.SessionCounter = $sessionCounter
$config | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8

$sessionName = "Capture_$sessionCounter"

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$baseName = "PresentMon_Capture_$sessionCounter`_$timestamp"
$presentMonOutputFile = "$scriptPath\$baseName.csv"

Clear-Host

Write-Host "Press $hotkey to start recording (auto-stops after $recordingDuration seconds)`n"

# No --process_name filter: with --multi_csv, PresentMon records whatever is
# actively rendering (game, benchmark, etc.) and writes one CSV per process.
$presentMonArgs = "--multi_csv --hotkey $hotkey --timed $recordingDuration --terminate_after_timed --session_name `"$sessionName`" --stop_existing_session --date_time --track_gpu_video --track_frame_type --track_hw_measurements --track_app_timing --track_pc_latency --no_console_stats --output_file `"$presentMonOutputFile`""

try {
    $presentMonProcess = Start-Process -FilePath $presentMonPath -ArgumentList $presentMonArgs -PassThru -NoNewWindow -ErrorAction Stop
} catch {
    Write-Host "ERROR starting PresentMon: $_" -ForegroundColor Red
    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

$gracePeriod = 120
$maxWait = $recordingDuration + $gracePeriod
$waitStartTime = Get-Date
while (-not $presentMonProcess.HasExited -and ($waitStartTime.AddSeconds($maxWait) -gt (Get-Date))) {
    Start-Sleep -Seconds 1
}

if (-not $presentMonProcess.HasExited) {
    Write-Host "`nHotkey not pressed in time. Forcing stop..." -ForegroundColor Yellow
    try {
        Stop-Process -Id $presentMonProcess.Id -Force -ErrorAction Stop
    } catch {
        Write-Host "Error while stopping PresentMon: $_" -ForegroundColor Red
    }

    # Killing the process directly can leave the underlying ETW trace session
    # running in the background, which then blocks the next recording with
    # "a trace session named ... is already running". Clean it up here.
    try {
        Start-Process -FilePath $presentMonPath -ArgumentList "--session_name `"$sessionName`" --terminate_existing_session" -NoNewWindow -Wait -ErrorAction Stop
    } catch {
        Write-Host "Could not clean up trace session: $_" -ForegroundColor Yellow
    }
}

# With --multi_csv, PresentMon appends the process name and PID to the
# filename per captured process (and may add -1, -2 etc for repeat captures),
# so search by pattern and wait for sizes to settle rather than assuming an
# exact filename.
$stableChecks = 0
$lastTotalSize = -1
$foundFiles = @()
for ($i = 0; $i -lt 15 -and $stableChecks -lt 2; $i++) {
    Start-Sleep -Milliseconds 500
    $foundFiles = @(Get-ChildItem -Path $scriptPath -Filter "$baseName*.csv" -ErrorAction SilentlyContinue)
    $curTotalSize = ($foundFiles | Measure-Object -Property Length -Sum).Sum
    if ($curTotalSize -eq $lastTotalSize) { $stableChecks++ } else { $stableChecks = 0 }
    $lastTotalSize = $curTotalSize
}

Write-Host ""

if ($foundFiles.Count -eq 0) {
    Write-Host "Recording failed. No CSV file was created. Check that $hotkey was pressed while something was rendering (e.g. a game), then try again." -ForegroundColor Red
} else {
    $anyNonEmpty = $false
    foreach ($f in $foundFiles) {
        $sizeKb = [math]::Round($f.Length / 1KB, 2)
        if ($f.Length -gt 0) {
            Write-Host "Saved: $($f.Name) ($sizeKb KB)" -ForegroundColor Green
            $anyNonEmpty = $true
        } else {
            Write-Host "Saved: $($f.Name) (0 KB, empty)" -ForegroundColor Yellow
        }
    }
    if (-not $anyNonEmpty) {
        Write-Host "`nAll captured files are empty. Check that $hotkey was pressed while something was rendering, then try again." -ForegroundColor Red
    }
}

Read-Host -Prompt "`nPress Enter to exit"
