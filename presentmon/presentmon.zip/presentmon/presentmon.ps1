# Check administrator privileges
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "This script requires administrator privileges to record traces." -ForegroundColor Red
    Write-Host "Please run the script as administrator." -ForegroundColor Yellow
    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "Script directory: $scriptPath"

# Check PresentMon dependencies
Write-Host "`nChecking PresentMon dependencies..." -ForegroundColor Cyan

$presentMonPath = "$scriptPath\PresentMon.exe"
$configPath = "$scriptPath\PresentMon_Config.json"

if (-not (Test-Path $presentMonPath)) {
    Write-Host "PresentMon.exe was not found in the script directory: $scriptPath" -ForegroundColor Red
    Write-Host "Download PresentMon from https://github.com/GameTechDev/PresentMon/releases, rename it to PresentMon.exe, then move it into the script folder" -ForegroundColor Yellow

    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

# ---------------------------------------------------------
# Default settings (used the very first time, before a config file exists)
# ---------------------------------------------------------
$defaultConfig = [PSCustomObject]@{
    ProcessName = "cs2.exe"
    Hotkey      = "F10"
    DurationSec = 30
}

function Show-Config($cfg) {
    Write-Host ""
    Write-Host "Current settings:" -ForegroundColor Cyan
    Write-Host "  Target process : $($cfg.ProcessName)"
    Write-Host "  Hotkey         : $($cfg.Hotkey)"
    Write-Host "  Duration       : $($cfg.DurationSec) seconds"
}

function Select-ProcessName($currentDefault) {
    Write-Host ""
    Write-Host "Currently running processes:" -ForegroundColor Cyan
    $procs = Get-Process | Where-Object { $_.MainWindowTitle -ne "" -or $_.ProcessName -notin @("System", "Idle") } `
        | Sort-Object ProcessName -Unique `
        | Select-Object -First 20

    $i = 1
    $procList = @()
    foreach ($p in $procs) {
        Write-Host ("  {0,2}) {1}.exe" -f $i, $p.ProcessName)
        $procList += "$($p.ProcessName).exe"
        $i++
    }

    Write-Host ""
    Write-Host "Type a number from the list above, or type an exe name directly (e.g. cs2.exe)."
    $input = Read-Host -Prompt "Process to record [$currentDefault]"

    if ([string]::IsNullOrWhiteSpace($input)) {
        return $currentDefault
    } elseif ($input -match '^\d+$' -and [int]$input -ge 1 -and [int]$input -le $procList.Count) {
        return $procList[[int]$input - 1]
    } else {
        if ($input -notmatch '\.exe$') { $input = "$input.exe" }
        return $input
    }
}

function Select-Hotkey($currentDefault) {
    $input = Read-Host -Prompt "Hotkey to start/stop recording [$currentDefault]"
    if ([string]::IsNullOrWhiteSpace($input)) { return $currentDefault }
    return $input
}

function Select-Duration($currentDefault) {
    $input = Read-Host -Prompt "Recording duration in seconds [$currentDefault]"
    if ([string]::IsNullOrWhiteSpace($input)) { return $currentDefault }
    if ($input -match '^\d+$') { return [int]$input }
    Write-Host "Invalid number, keeping default ($currentDefault)." -ForegroundColor Yellow
    return $currentDefault
}

# ---------------------------------------------------------
# Load or create config
# ---------------------------------------------------------
$config = $null
if (Test-Path $configPath) {
    try {
        $config = Get-Content $configPath -Raw | ConvertFrom-Json
        Show-Config $config
        $useExisting = Read-Host -Prompt "`nPress Enter to use these settings, or type 'edit' to change them"
    } catch {
        Write-Host "Could not read existing config file, it may be corrupted. Reconfiguring..." -ForegroundColor Yellow
        $config = $null
        $useExisting = "edit"
    }
} else {
    Write-Host "No config file found. Let's set one up." -ForegroundColor Yellow
    $config = $defaultConfig
    $useExisting = "edit"
}

if ($useExisting -eq "edit") {
    $newProcessName = Select-ProcessName $config.ProcessName
    $newHotkey      = Select-Hotkey $config.Hotkey
    $newDuration    = Select-Duration $config.DurationSec

    $config = [PSCustomObject]@{
        ProcessName = $newProcessName
        Hotkey      = $newHotkey
        DurationSec = $newDuration
    }

    $config | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8
    Write-Host "`nSettings saved to: $configPath" -ForegroundColor Green
    Write-Host "You can edit this file directly next time if you want to tweak values by hand." -ForegroundColor Gray
}

$processName       = $config.ProcessName
$hotkey            = $config.Hotkey
$recordingDuration = $config.DurationSec

# Persistent unique session id: increments every run, stored in the config file.
if ($config.PSObject.Properties.Name -contains 'SessionCounter') {
    $sessionCounter = [int]$config.SessionCounter + 1
} else {
    $sessionCounter = 1
    $config | Add-Member -NotePropertyName SessionCounter -NotePropertyValue 0 -Force
}
$config.SessionCounter = $sessionCounter
$config | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8

$appLabel = $processName -replace '\.exe$', '' -replace '[^a-zA-Z0-9]', ''
$sessionName = "$appLabel`_$sessionCounter"

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$baseName = "PresentMon_$appLabel`_$sessionCounter`_$timestamp"
$presentMonOutputFile = "$scriptPath\$baseName.csv"

Clear-Host

Write-Host "Press $hotkey to start recording (auto-stops after $recordingDuration seconds)`n"

$presentMonArgs = "--process_name `"$processName`" --hotkey $hotkey --timed $recordingDuration --terminate_after_timed --session_name `"$sessionName`" --stop_existing_session --date_time --track_gpu_video --track_frame_type --track_hw_measurements --track_app_timing --track_pc_latency --no_console_stats --output_file `"$presentMonOutputFile`""

try {
    $presentMonProcess = Start-Process -FilePath $presentMonPath -ArgumentList $presentMonArgs -PassThru -NoNewWindow -ErrorAction Stop
} catch {
    Write-Host "ERROR starting PresentMon: $_" -ForegroundColor Red
    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

$gracePeriod = 120
$maxWait = $recordingDuration + $gracePeriod
$waitStartTime = Get-Date
while (-not $presentMonProcess.HasExited -and ($waitStartTime.AddSeconds($maxWait) -gt (Get-Date))) {
    Start-Sleep -Seconds 1
}

# PresentMon appends -1, -2, etc. to the filename when using --hotkey (in case
# of multiple start/stop captures per run), so the actual file may not match
# the exact path we requested. Search by pattern and wait for its size to settle.
$stableChecks = 0
$lastSize = -1
$actualFile = $null
for ($i = 0; $i -lt 15 -and $stableChecks -lt 2; $i++) {
    Start-Sleep -Milliseconds 500
    $found = Get-ChildItem -Path $scriptPath -Filter "$baseName*.csv" -ErrorAction SilentlyContinue |
        Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($found) {
        $actualFile = $found
        $curSize = $found.Length
        if ($curSize -eq $lastSize) { $stableChecks++ } else { $stableChecks = 0 }
        $lastSize = $curSize
    }
}
if ($actualFile) { $presentMonOutputFile = $actualFile.FullName }

Write-Host ""

if (-not $presentMonProcess.HasExited) {
    Write-Host "`nHotkey not pressed in time. Forcing stop..." -ForegroundColor Yellow
    try {
        Stop-Process -Id $presentMonProcess.Id -Force -ErrorAction Stop
    } catch {
        Write-Host "Error while stopping PresentMon: $_" -ForegroundColor Red
    }

    # Killing the process directly can leave the underlying ETW trace session
    # running in the background, which then blocks the next recording with
    # "a trace session named PresentMon is already running". Clean it up here.
    try {
        Start-Process -FilePath $presentMonPath -ArgumentList "--session_name `"$sessionName`" --terminate_existing_session" -NoNewWindow -Wait -ErrorAction Stop
    } catch {
        Write-Host "Could not clean up trace session: $_" -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Saved to: $presentMonOutputFile"

$fileOk = $false
if (Test-Path $presentMonOutputFile -PathType Leaf) {
    $csvSize = (Get-Item $presentMonOutputFile).Length
    if ($csvSize -gt 0) {
        Write-Host "Recording successful. Size: $([math]::Round($csvSize / 1KB, 2)) KB" -ForegroundColor Green
        $fileOk = $true
    }
}

if (-not $fileOk) {
    Write-Host "Recording failed. Check that '$processName' was running and that $hotkey was pressed, then try again." -ForegroundColor Red
}

Read-Host -Prompt "`nPress Enter to exit"
