# Check administrator privileges
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "This script requires administrator privileges to record traces." -ForegroundColor Red
    Write-Host "Please run the script as administrator." -ForegroundColor Yellow
    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

$scriptPath = Split-Path -Parent $MyInvocation.MyCommand.Definition
Write-Host "Script directory: $scriptPath"

# Check PresentMon dependencies
Write-Host "`nChecking PresentMon dependencies..." -ForegroundColor Cyan

$presentMonPath = "$scriptPath\PresentMon.exe"
$configPath = "$scriptPath\PresentMon_Config.json"

if (-not (Test-Path $presentMonPath)) {
    Write-Host "PresentMon.exe was not found in the script directory: $scriptPath" -ForegroundColor Red
    Write-Host "Download PresentMon from https://github.com/GameTechDev/PresentMon/releases, rename it to PresentMon.exe, then move it into the script folder" -ForegroundColor Yellow

    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

# ---------------------------------------------------------
# Default settings (used the very first time, before a config file exists)
# ---------------------------------------------------------
$defaultConfig = [PSCustomObject]@{
    ProcessName = "cs2.exe"
    Hotkey      = "F10"
    DurationSec = 30
}

function Show-Config($cfg) {
    Write-Host ""
    Write-Host "Current settings:" -ForegroundColor Cyan
    Write-Host "  Target process : $($cfg.ProcessName)"
    Write-Host "  Hotkey         : $($cfg.Hotkey)"
    Write-Host "  Duration       : $($cfg.DurationSec) seconds"
}

function Select-ProcessName($currentDefault) {
    Write-Host ""
    Write-Host "Currently running processes:" -ForegroundColor Cyan
    $procs = Get-Process | Where-Object { $_.MainWindowTitle -ne "" -or $_.ProcessName -notin @("System", "Idle") } `
        | Sort-Object ProcessName -Unique `
        | Select-Object -First 20

    $i = 1
    $procList = @()
    foreach ($p in $procs) {
        Write-Host ("  {0,2}) {1}.exe" -f $i, $p.ProcessName)
        $procList += "$($p.ProcessName).exe"
        $i++
    }

    Write-Host ""
    Write-Host "Type a number from the list above, or type an exe name directly (e.g. cs2.exe)."
    $input = Read-Host -Prompt "Process to record [$currentDefault]"

    if ([string]::IsNullOrWhiteSpace($input)) {
        return $currentDefault
    } elseif ($input -match '^\d+$' -and [int]$input -ge 1 -and [int]$input -le $procList.Count) {
        return $procList[[int]$input - 1]
    } else {
        if ($input -notmatch '\.exe$') { $input = "$input.exe" }
        return $input
    }
}

function Select-Hotkey($currentDefault) {
    $input = Read-Host -Prompt "Hotkey to start/stop recording [$currentDefault]"
    if ([string]::IsNullOrWhiteSpace($input)) { return $currentDefault }
    return $input
}

function Select-Duration($currentDefault) {
    $input = Read-Host -Prompt "Recording duration in seconds [$currentDefault]"
    if ([string]::IsNullOrWhiteSpace($input)) { return $currentDefault }
    if ($input -match '^\d+$') { return [int]$input }
    Write-Host "Invalid number, keeping default ($currentDefault)." -ForegroundColor Yellow
    return $currentDefault
}

# ---------------------------------------------------------
# Load or create config
# ---------------------------------------------------------
$config = $null
if (Test-Path $configPath) {
    try {
        $config = Get-Content $configPath -Raw | ConvertFrom-Json
        Show-Config $config
        $useExisting = Read-Host -Prompt "`nPress Enter to use these settings, or type 'edit' to change them"
    } catch {
        Write-Host "Could not read existing config file, it may be corrupted. Reconfiguring..." -ForegroundColor Yellow
        $config = $null
        $useExisting = "edit"
    }
} else {
    Write-Host "No config file found. Let's set one up." -ForegroundColor Yellow
    $config = $defaultConfig
    $useExisting = "edit"
}

if ($useExisting -eq "edit") {
    $newProcessName = Select-ProcessName $config.ProcessName
    $newHotkey      = Select-Hotkey $config.Hotkey
    $newDuration    = Select-Duration $config.DurationSec

    $config = [PSCustomObject]@{
        ProcessName = $newProcessName
        Hotkey      = $newHotkey
        DurationSec = $newDuration
    }

    $config | ConvertTo-Json | Set-Content -Path $configPath -Encoding UTF8
    Write-Host "`nSettings saved to: $configPath" -ForegroundColor Green
    Write-Host "You can edit this file directly next time if you want to tweak values by hand." -ForegroundColor Gray
}

$processName       = $config.ProcessName
$hotkey            = $config.Hotkey
$recordingDuration = $config.DurationSec

Show-Config $config

$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$presentMonOutputFile = "$scriptPath\PresentMon_Recording_$timestamp.csv"

Write-Host "`nPresentMon recording will be saved to: $presentMonOutputFile"

Write-Host "`nSTARTING PRESENTMON..."
Write-Host "Press $hotkey at any time to start recording. Recording will automatically stop after $recordingDuration seconds."
Write-Host "Process being tracked: $processName"

# PresentMon arguments
# --track_pc_latency requires PresentMon 2.5.0+ (present in your 2.5.1 build).
# --no_console_stats reduces console rendering overhead during capture.
$presentMonArgs = "--process_name `"$processName`" --hotkey $hotkey --timed $recordingDuration --terminate_after_timed --date_time --track_gpu_video --track_frame_type --track_hw_measurements --track_app_timing --track_pc_latency --no_console_stats --output_file `"$presentMonOutputFile`""

# Start PresentMon
Write-Host "`nStarting PresentMon..." -ForegroundColor Cyan
try {
    $presentMonProcess = Start-Process -FilePath $presentMonPath -ArgumentList $presentMonArgs -PassThru -NoNewWindow -ErrorAction Stop
    Write-Host "PresentMon started successfully (PID: $($presentMonProcess.Id))" -ForegroundColor Green
} catch {
    Write-Host "ERROR starting PresentMon: $_" -ForegroundColor Red
    Read-Host -Prompt "Press Enter to exit"
    exit 1
}

# Wait for the hotkey to be pressed and the recording to complete.
# Grace period gives time to press the hotkey before the max wait is hit.
$gracePeriod = 120
$maxWait = $recordingDuration + $gracePeriod
Write-Host "`nWaiting up to $maxWait seconds total (hotkey press + $recordingDuration seconds recording)..."

$waitStartTime = Get-Date
while (-not $presentMonProcess.HasExited -and ($waitStartTime.AddSeconds($maxWait) -gt (Get-Date))) {
    Start-Sleep -Seconds 1
}

Write-Host "`n=== STOPPING PRESENTMON RECORDING ===" -ForegroundColor Cyan
$stopTime = Get-Date
Write-Host "Approximate stop check time: $($stopTime.ToString('HH:mm:ss.fff'))"

if ($presentMonProcess.HasExited) {
    Write-Host "PresentMon finished successfully" -ForegroundColor Green
} else {
    Write-Host "PresentMon did not finish automatically (hotkey may not have been pressed in time). Forcing stop..." -ForegroundColor Yellow
    try {
        Stop-Process -Id $presentMonProcess.Id -Force -ErrorAction Stop
        Write-Host "PresentMon force stopped" -ForegroundColor Yellow
    } catch {
        Write-Host "Error while stopping PresentMon: $_" -ForegroundColor Red
    }
}

Write-Host "`n=== PRESENTMON RECORDING RESULTS ===" -ForegroundColor Cyan
Write-Host "Recording check finished at approximately $(Get-Date)"
Write-Host "PresentMon trace saved to: $presentMonOutputFile"

# File size validation results
$validationResults = @{}

if (Test-Path $presentMonOutputFile -PathType Leaf) {
    $csvFileInfo = Get-Item $presentMonOutputFile
    $csvSize = $csvFileInfo.Length
    $validationResults.PresentMon_Size = $csvSize

    if ($csvSize -gt 0) {
        Write-Host "PresentMon file created successfully. Size: $([math]::Round($csvSize / 1KB, 2)) KB" -ForegroundColor Green
    } else {
        Write-Host "WARNING: PresentMon file was created but has zero size (0 bytes)!" -ForegroundColor Red
        Write-Host "   This usually means the hotkey was never pressed, or the process '$processName' was not running." -ForegroundColor Yellow
        Write-Host "   Currently running processes with a similar name:" -ForegroundColor Yellow

        $similarProcesses = Get-Process | Where-Object { $_.ProcessName -like "*$($processName.Split('.')[0])*" } | Select-Object -First 5
        if ($similarProcesses) {
            $similarProcesses | ForEach-Object {
                Write-Host "     - $($_.ProcessName) (PID: $($_.Id), CPU: $($_.CPU)%, RAM: $([math]::Round($_.WS / 1MB, 1)) MB)" -ForegroundColor Gray
            }
        } else {
            Write-Host "     - No similar running processes found" -ForegroundColor Gray
        }
    }
} else {
    Write-Host "PresentMon file was NOT created! Check that the process '$processName' is running and that you have administrator privileges." -ForegroundColor Red
    $validationResults.PresentMon_Exists = $false

    Write-Host "`nAvailable processes to track:" -ForegroundColor Yellow
    $topProcesses = Get-Process | Sort-Object CPU -Descending | Select-Object -First 10
    $topProcesses | ForEach-Object {
        Write-Host "  - $($_.ProcessName) (PID: $($_.Id), CPU: $($_.CPU)%, RAM: $([math]::Round($_.WS / 1MB, 1)) MB)" -ForegroundColor Gray
    }
}

# Summary report
Write-Host "`n=== PRESENTMON SUMMARY REPORT ===" -ForegroundColor Cyan
Write-Host "Hotkey: $hotkey"
Write-Host "Recording duration: $recordingDuration seconds"
Write-Host "Target process: $processName"
Write-Host "Config file: $configPath"
Write-Host "PresentMon status: $(if ($validationResults.PresentMon_Size -gt 0) {"SUCCESS"} elseif ($validationResults.PresentMon_Exists -eq $false) {"FILE NOT CREATED"} else {"ZERO SIZE"})"

if ($validationResults.PresentMon_Size -eq 0 -or $validationResults.PresentMon_Size -eq $null) {
    Write-Host "`nWARNING: Issues were detected with the PresentMon recording!" -ForegroundColor Red
    Write-Host "   It is recommended to repeat the recording and make sure that:" -ForegroundColor Yellow
    Write-Host "   - The process '$processName' is running before the script starts" -ForegroundColor Yellow
    Write-Host "   - You pressed $hotkey to actually start the recording" -ForegroundColor Yellow
    Write-Host "   - There is enough disk space" -ForegroundColor Yellow
    Write-Host "   - There are no conflicting monitoring tools" -ForegroundColor Yellow
    Write-Host "   - PresentMon.exe has the necessary access permissions" -ForegroundColor Yellow
}

Read-Host -Prompt "`nPress Enter to exit"
